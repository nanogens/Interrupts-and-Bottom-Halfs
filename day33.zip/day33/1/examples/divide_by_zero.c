#include <stdio.h>

int main()
{
	int i = 1/0;
	return 0;
}
